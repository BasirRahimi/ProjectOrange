
<?php $__env->startSection('content'); ?>

<div class="request-access-container">
    <div class="header">
        <?php if(auth()->guard()->check()): ?>
        <a class="log-in" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">Log out</a>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
        <a class="log-in" href="/login">Log in</a>
        <?php endif; ?>
    </div>
    <div class="router-view">
        <request-access user-prop="<?php echo e($user); ?>"></request-access>
    </div>
    <div class="footer">
        <p>By confirming your email, you agree to our <a href="#">Terms of Service</a> and that you have read and understood our <a href="#">Privacy Policy</a></p>
    </div>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sites\ProjectOrange\resources\views/auth/request-access.blade.php ENDPATH**/ ?>