<?php $__env->startComponent('mail::message'); ?>
# Welcome to Project Orange

This is your temporary password:

**<?php echo e($tempPassword); ?>**

Please change it when you [log in](<?php echo e(config('app.url')); ?>).

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Sites\ProjectOrange\resources\views/emails/account-created-with-temp-pwd-mail.blade.php ENDPATH**/ ?>