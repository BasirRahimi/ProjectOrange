<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> <?php if (! empty(trim($__env->yieldContent('title')))): ?>- <?php echo $__env->yieldContent('title'); ?> <?php endif; ?></title>

    <?php if($client_form_id ?? ''): ?>
    <script>
        window.clientFormId = <?php echo e($client_form_id ?? ''); ?>;
    </script>
    <?php endif; ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/argon.css')); ?>" rel="stylesheet">

    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.typekit.net/lxw2fcr.css">
</head>
<body>
    <div id="app">
        <?php $user = Auth::user(); ?>
        <?php if($user): ?>
        <?php if($user->has_access): ?>
        <nav class="navbar navbar-expand navbar-light bg-white shadow-sm sticky-top p-0 px-lg-3 py-lg-2">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                

                
                <div>
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <base-dropdown tag="li" class="nav-item" menu-classes="shadow" position="right">
                            <base-button slot="title" type="link" class="dropdown-toggle m-0 nav-link">
                            <?php echo e($user->name); ?> <span class="caret"></span>
                            </base-button>
                            
                            <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-item"><?php echo e(__('Dashboard')); ?></a>
                            
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                        </base-dropdown>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php endif; ?>
        <?php endif; ?>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH D:\Sites\ProjectOrange\resources\views/layouts/app.blade.php ENDPATH**/ ?>