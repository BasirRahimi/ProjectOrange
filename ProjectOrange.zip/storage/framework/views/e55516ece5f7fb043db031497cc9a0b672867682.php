<?php $__env->startComponent('mail::message'); ?>
# Welcome to Project Orange 

Your temporary password is:

1234

Please change it when you [log in](<?php echo e(config('app.url') . '/login'); ?>).

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Sites\ProjectOrange\resources\views/emails/request-access.blade.php ENDPATH**/ ?>