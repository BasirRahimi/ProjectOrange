<template>
    <div class="container">
        <content-box title="Welcome to Project Orange">
            <p class="text-muted m-0">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet</p>
        </content-box>
        <content-box title="About the Deceased">
            <honorific v-model="formData.honorific"/>

            <base-input placeholder="John" v-model="formData.forename" label="Forename"></base-input>
            <base-input placeholder="Doe" v-model="formData.surname" label="Surname"></base-input>
            <base-input placeholder="Johnathan Doe" v-model="formData.aliases" label="Any aliases in which they held assets?"></base-input>

            <div class="form-group">
                <label>Last usual address</label><br/>
                <base-radio inline name="postcode" v-model="addressInputType" value="manual">Find with postcode</base-radio>
                <base-radio inline name="manual" v-model="addressInputType" value="manual">Add manually</base-radio>
            </div>

            <div class="row">
                <div class="col-lg-5 form-group" v-show="addressInputType == 'postcode'">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="E.g. TN30 6RN">
                        <div class="input-group-append">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-12" v-show="addressInputType == 'manual'">
                    <div class="row">
                        <div class="col-lg-5 form-group" >
                            <label for="addressLine1">Address Line 1</label>
                            <input type="text" id="addressLine1" class="form-control" placeholder="23 Acacia Avenue" v-model="formData.addressLine1">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 form-group">
                            <label for="addressLine2">Address Line 2</label>
                            <input type="text" id="addressLine2" class="form-control" placeholder="Acacia Road" v-model="formData.addressLine2">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 form-group">
                            <label for="town">Town / City</label>
                            <input type="text" id="town" class="form-control" placeholder="Acadia" v-model="formData.town">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-5 form-group">
                            <label for="postcode">Postcode</label>
                            <input type="text" id="postcode" class="form-control" placeholder="TN28 PJ13" v-model="formData.postcode">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-5">
                    <label for="aliases">Date of Death</label>
                    <datepicker input-class="form-control bg-white" v-model="formData.dateOfDeath" placeholder="21 / 9 / 2020" format="dd / MM / yy"></datepicker>
                </div>
            </div>
        </content-box>
        <content-box title="1.2 Key Information">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <base-input
                        class="mb-3 mb-lg-0"
                        label="Place of Birth" 
                        placeholder="Maidstone, Kent" 
                        v-model="formData.placeOfBirth"
                        :form-group="false"></base-input>
                </div>
                <div class="col-12 col-lg-6">
                    <base-input 
                        label="Place of Death" 
                        placeholder="Wandsworth, London" 
                        v-model="formData.placeOfDeath"
                        :form-group="false"></base-input>
                </div>
            </div>
        </content-box>
        <content-box title="1.3 Marital Status">
            <div class="button-grid">
                <base-button type="default" outline :class="{active: formData.maritalStatus == 'Married'}" @click="formData.maritalStatus = 'Married'">Married</base-button>
                <base-button type="default" outline :class="{active: formData.maritalStatus == 'Batchelor'}" @click="formData.maritalStatus = 'Batchelor'">Batchelor</base-button>
                <base-button type="default" outline :class="{active: formData.maritalStatus == 'Divorced'}" @click="formData.maritalStatus = 'Divorced'">Divorced</base-button>
                <base-button type="default" outline :class="{active: formData.maritalStatus == 'Widowed'}" @click="formData.maritalStatus = 'Widowed'">Widowed</base-button>
                <base-button type="default" outline :class="{active: formData.maritalStatus == 'Spinster'}" @click="formData.maritalStatus = 'Spinster'">Spinster</base-button>
            </div>
            <!-- <button-group cssGrid :options="['Married','Batchelor','Divorced','Widowed','Spinster']" sameWidthButtons v-model="formData.maritalStatus"/> -->
        </content-box>
        <content-box title="1.4 Surviving Relatives">
            <div class="button-grid">
                <base-button type="default" outline @click="updateSurvivingRelatives('spouse')" :class="{'active': formData.survivingRelatives.spouse > 0}" class="col mr-3">Spouse</base-button>
                <base-button type="default" outline @click="updateSurvivingRelatives('parents')" :class="{'active': formData.survivingRelatives.parents > 0}" class="col mr-3">Parents</base-button>
                <base-button type="default" outline @click="updateSurvivingRelatives('siblings')" :class="{'active': formData.survivingRelatives.siblings > 0}" class="col mr-3">Siblings</base-button>
                <base-button type="default" outline @click="updateSurvivingRelatives('children')" :class="{'active': formData.survivingRelatives.children > 0}" class="col mr-3">Children</base-button>
                <base-button type="default" outline @click="updateSurvivingRelatives('grandChildren')" :class="{'active': formData.survivingRelatives.grandChildren > 0}" class="col">Grand Children</base-button>
                <!-- <button @click="formData.survivingRelatives.spouse === 0 ? formData.survivingRelatives.spouse = 1 : formData.survivingRelatives.spouse = 0" class="btn btn-outline-secondary active-primary" :class="{'active': formData.survivingRelatives.spouse > 0}">Spouse</button>
                <button @click="formData.survivingRelatives.parents === 0 ? formData.survivingRelatives.parents = 1 : formData.survivingRelatives.parents = 0" class="btn btn-outline-secondary active-primary" :class="{'active': formData.survivingRelatives.parents > 0}">Parents</button>
                <button @click="formData.survivingRelatives.siblings === 0 ? formData.survivingRelatives.siblings = 1 : formData.survivingRelatives.siblings = 0" class="btn btn-outline-secondary active-primary" :class="{'active': formData.survivingRelatives.siblings > 0}">Siblings</button>
                <button @click="formData.survivingRelatives.children === 0 ? formData.survivingRelatives.children = 1 : formData.survivingRelatives.children = 0" class="btn btn-outline-secondary active-primary" :class="{'active': formData.survivingRelatives.children > 0}">Children</button>
                <button @click="formData.survivingRelatives.grandChildren === 0 ? formData.survivingRelatives.grandChildren = 1 : formData.survivingRelatives.grandChildren = 0" class="btn btn-outline-secondary active-primary" :class="{'active': formData.survivingRelatives.grandChildren > 0}">Grand Children</button> -->
            </div>
            <b-collapse :visible="formData.survivingRelatives.parents > 0">
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <label for="noOfParents">Number of Surviving Parents</label>
                        <input type="number" id="noOfParents" class="form-control" placeholder="John" v-model.number="formData.survivingRelatives.parents">
                    </div>
                </div>
            </b-collapse>
            <b-collapse :visible="formData.survivingRelatives.siblings > 0">
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <label for="noOfSiblings">Number of Surviving Siblings</label>
                        <input type="number" id="noOfSiblings" class="form-control" placeholder="John" v-model.number="formData.survivingRelatives.siblings">
                    </div>
                </div>
            </b-collapse>
            <b-collapse :visible="formData.survivingRelatives.children > 0">
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <label for="noOfChildren">Number of Surviving Children</label>
                        <input type="number" id="noOfChildren" class="form-control" placeholder="John" v-model.number="formData.survivingRelatives.children">
                    </div>
                </div>
            </b-collapse>
            <b-collapse :visible="formData.survivingRelatives.grandChildren > 0">
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <label for="noOfGrandChildren">Number of Surviving Grand Children</label>
                        <input type="number" id="noOfGrandChildren" class="form-control" placeholder="John" v-model.number="formData.survivingRelatives.grandChildren">
                    </div>
                </div>
            </b-collapse>
        </content-box>
        <content-box title="1.5 Income tax details">
            <div class="row">
                <div class="col-12 col-lg-6 form-group">
                    <label for="NInumber">National insurance number</label>
                    <input type="text" class="form-control" id="NInumber" placeholder="576HDIW7 IE" v-model="formData.niNumber">
                </div>
                <div class="col-12 col-lg-6 form-group">
                    <label for="tax-ref">Income tax reference</label>
                    <input type="text" class="form-control" id="tax-ref" placeholder="5678 DVW 09" v-model="formData.incomeTaxRef">
                </div>
                <div class="col-12 mb-2">
                    <label>The contact details of the deceased’s accountant</label>
                </div>
                <div class="col-12 col-lg-6 form-group">
                    <label for="phone">Phone number</label>
                    <input type="text" class="form-control" id="phone" placeholder="+44 012345 67890" v-model="formData.phone">
                </div>
                <div class="col-12 col-lg-6 form-group">
                    <label for="email">Email Address</label>
                    <input type="text" class="form-control" id="email" placeholder="John.doe@doe.co.uk" v-model="formData.email">
                </div>
            </div>
        </content-box>
        <content-box class="p-0 text-right" :shadow="false" :whiteBg="false">
            <button class="btn btn-primary shadow" @click="$router.push({name:'section2'})">Next section</button>
        </content-box>
    </div>
</template>

<script>
import Datepicker from 'vuejs-datepicker';
import Honorific from '../form-snippets/Honorific.vue';
import ButtonGroup from '../form-snippets/ButtonGroup.vue';
export default {
    components: {
        Datepicker,
        Honorific,
        ButtonGroup
    },
    data() {
        return {
            formData: {
                honorific: '',
                forename: '',
                surname: '',
                aliases: '',
                addressLine1: '',
                addressLine2: '',
                town: '',
                postcode: '',
                dateOfDeath: '',
                placeOfBirth: '',
                placeOfDeath: '',
                maritalStatus: '',
                survivingRelatives: {
                    spouse: 0,
                    parents: 0,
                    siblings: 0,
                    children: 0,
                    grandChildren: 0,
                },
                niNumber: '',
                incomeTaxRef: '',
                phone: '',
                email: '',
            },
            addressInputType: 'manual'
        }
    },
    methods: {
        updateSurvivingRelatives(relative) {
            if(this.formData.survivingRelatives[relative] === 0) {
                this.formData.survivingRelatives[relative] = 1;
            } else {
                this.formData.survivingRelatives[relative] = 0;
            }

        }
    }
}
</script>

<style lang="scss" scoped>
</style>