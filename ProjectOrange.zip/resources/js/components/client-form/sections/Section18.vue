<template>
    <div class="container">
        <content-box title="Section 17 - Personal belongings (owned solely by the deceased)">
            <p class="text-gray-500 m-0">HMRC requires information about all chattels held by the deceased.</p>
        </content-box>

        <content-box title="17.1 Chattels">
            <yes-no collapse label="Did the deceased own any Chattels of particular value?" class="mb-4">
                <table class="asset-table mt-4">
                    <thead>
                        <tr>
                            <th>Description of Chattels</th>
                            <th>Value £</th>
                        </tr>
                        <tr class="spacer"></tr>
                    </thead>
                    <tbody>
                        <template v-for="(row, i) in rows">
                            <tr :key="i">
                                <td>
                                    <input type="text" v-model="row.description">
                                </td>
                                <td>
                                    <input type="number" step=".01" min="0" v-model="row.value">
                                </td>
                            </tr>
                            <tr class="spacer-sm" :key="`spacer${i}`"></tr>
                        </template>
                    </tbody>
                </table>
                <base-button type="default" outline class="ml-auto d-block" @click="addRow">Add</base-button>
            </yes-no>

            <a v-b-toggle.collapse1 class="pointer">Tip<i class="icon-xs fas fa-chevron-down ml-2"></i></a>
            <b-collapse visible id="collapse1">
                <p class="text-gray-500 mt-2 mb-0">If the deceased was, for example, married and acquired furniture and household effects with their spouse, it could be the case that such items were owned jointly and so you should include jointly owned possessions in section 14. Unless the total value of the Chattels owned by the deceased is likely to exceed £1,000 there is usually no need to obtain a formal valuation. Include below Items such as cars, jewellery, etc.</p>
            </b-collapse>
        </content-box>
  </div>
</template>

<script>
import YesNo from '../form-snippets/YesNo';
export default {
    components: {
        YesNo
    },
    data() {
        return {
            rows: []
        }
    },
    methods: {
        addRow() {
            this.rows.push({
                description: '',
                value: ''
            });
        }
    }
}
</script>

<style lang="scss" scoped>

</style>