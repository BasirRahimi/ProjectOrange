<template>
    <div class="container">
        <content-box title="Overview">
            
        </content-box>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>