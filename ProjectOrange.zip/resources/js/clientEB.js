// This is the client event bus
import Vue from 'vue';
const clientEB = new Vue();
export default clientEB;