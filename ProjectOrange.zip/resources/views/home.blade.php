@extends('layouts.app')
@section('title', 'Dashboard')
@section('content')
<user-dashboard class="mt-3"></user-dashboard>
@endsection
