@extends('layouts.app')
@section('title', 'Client Form')

@section('content')
<client-form></client-form>
@endsection